package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.Pais;
import org.springframework.stereotype.Repository;

@Repository
public interface PaisRepository extends BaseRepository<Pais, Long> {
}
