package com.example.ElBuenSabor.repositories;

//import com.example.ElBuenSabor.entities.Base;
import com.example.ElBuenSabor.entities.ImagenArticulo;
import org.springframework.stereotype.Repository;

@Repository
public interface ImagenArticuloRepository extends BaseRepository<ImagenArticulo, Long> {
}
