package com.example.ElBuenSabor.entities.enums;

public enum TipoEnvio {
    DELIVERY,
    TAKEAWAY
}
