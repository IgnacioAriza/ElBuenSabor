package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.ArticuloManufacturado;
import org.springframework.stereotype.Repository;

@Repository
public interface ArticuloManufacturadoRepository extends BaseRepository<ArticuloManufacturado, Long>{

}
