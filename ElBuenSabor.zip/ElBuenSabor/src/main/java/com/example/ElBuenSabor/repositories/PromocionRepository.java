package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.Promocion;
import org.springframework.stereotype.Repository;

@Repository
public interface PromocionRepository extends BaseRepository<Promocion, Long> {
}
