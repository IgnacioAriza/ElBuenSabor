package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.ImagenEmpleado;

import org.springframework.stereotype.Repository;

@Repository
public interface ImagenEmpleadoRepository extends BaseRepository<ImagenEmpleado, Long> {
}
