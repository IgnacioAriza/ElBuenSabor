package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.ImagenPromocion;
import org.springframework.stereotype.Repository;

@Repository
public interface ImagenPromocionRepository extends BaseRepository<ImagenPromocion, Long> {
}
