package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.UsuarioEmpleado;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioEmpleadoRepository extends BaseRepository<UsuarioEmpleado, Long> {
}
