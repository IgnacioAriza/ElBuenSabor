package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.UsuarioCliente;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioClienteRepository extends BaseRepository<UsuarioCliente, Long> {
}
