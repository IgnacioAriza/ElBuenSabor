package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.ArticuloInsumo;
import org.springframework.stereotype.Repository;

@Repository
public interface ArticuloInsumoRepository extends BaseRepository<ArticuloInsumo, Long>{
}
