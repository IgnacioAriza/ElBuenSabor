package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.ImagenCliente;
import com.example.ElBuenSabor.entities.ImagenCliente;
import org.springframework.stereotype.Repository;

@Repository
public interface ImagenClienteRepository extends BaseRepository<ImagenCliente, Long> {
}
