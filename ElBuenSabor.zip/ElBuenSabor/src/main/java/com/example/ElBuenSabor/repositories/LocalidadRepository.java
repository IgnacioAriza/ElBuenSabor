package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.Localidad;
import org.springframework.stereotype.Repository;

@Repository
public interface LocalidadRepository extends BaseRepository<Localidad, Long> {
}
