package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.Provincia;
import org.springframework.stereotype.Repository;

@Repository
public interface ProvinciaRepository extends BaseRepository<Provincia, Long> {
}
