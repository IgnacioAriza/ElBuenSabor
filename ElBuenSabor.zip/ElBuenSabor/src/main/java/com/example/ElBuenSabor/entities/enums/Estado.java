package com.example.ElBuenSabor.entities.enums;

public enum Estado {
    PREPARACION,
    PENDIENTE,
    CANCELADO,
    RECHAZADO,
    ENTREGADO
}
