package com.example.ElBuenSabor.entities.enums;

public enum TipoPromocion {
    HAPPYHOUR,
    PROMOCION
}
