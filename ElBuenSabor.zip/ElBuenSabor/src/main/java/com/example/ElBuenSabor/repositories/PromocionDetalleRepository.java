package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.PromocionDetalle;
import org.springframework.stereotype.Repository;

@Repository
public interface PromocionDetalleRepository extends BaseRepository<PromocionDetalle, Long> {
}
