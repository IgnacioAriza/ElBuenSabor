package com.example.ElBuenSabor.repositories;

import com.example.ElBuenSabor.entities.UnidadMedida;
import org.springframework.stereotype.Repository;

@Repository
public interface UnidadMedidaRepository extends BaseRepository<UnidadMedida, Long> {
}
